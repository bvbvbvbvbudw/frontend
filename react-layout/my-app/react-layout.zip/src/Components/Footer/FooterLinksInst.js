import React from "react";

export default function FooterLinksInst({src}) {

    return (<>

        <a className="instagram__item" href="#" target="_blank">
            <img src={src} alt="" />
        </a>

    </>)
}