import React from 'react';

export default function TitleH3 ({className, children}) {

    return(<>
    
    <h3 className={className}>{children}</h3>
    
    </>)
}