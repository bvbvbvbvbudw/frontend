import React from "react";

export default function P({className, children}){


    return(<>
    
        <p className={className}>{children}</p>
    
    </>)
}