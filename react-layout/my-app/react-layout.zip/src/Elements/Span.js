import React from 'react';

export default function ({className , text}){

    return(<>
    
    <span className={className}>{text}</span>

    </>)
}