import './App.css';
import './Styles/style.css'

import Game from './Components/Game';

function App() {
  return (
    <div className="App">
        <Game />
    </div>
  );
}

export default App;
